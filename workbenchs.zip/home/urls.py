from django.conf.urls import url
from . import views

app_name = 'home'

urlpatterns = [
    url(r'^$', views.index, name='index'),
    url(r'^register/$', views.register, name='register'),
    url(r'^login_user/$', views.login_user, name='login_user'),
    url(r'^logout_user/$', views.logout_user, name='logout_user'),
    url(r'^create_que/$', views.create_que, name='create_que'),
    url(r'^(?P<que_id>[0-9]+)/create_ans/$', views.create_ans, name='create_ans'),
    url(r'^(?P<que_id>[0-9]+)/$', views.detail, name='detail'),
    url(r'^(?P<que_id>[0-9]+)/delete_que/$', views.delete_que, name='delete_que'),
    url(r'^(?P<que_id>[0-9]+)/delete_ans/(?P<ans_id>[0-9]+)/$', views.delete_ans, name='delete_ans'),
    url(r'^(?P<que_id>[0-9]+)/favorite_que/$', views.favorite_que, name='favorite_que'),
    url(r'^(?P<ans_id>[0-9]+)/favorite/$', views.favorite, name='favorite'),
    url(r'^anss/(?P<filter_by>[a-zA_Z]+)/$', views.anss, name='anss'),
    url(r'^profile$', views.CreateProfile, name='Profile'),
    url(r'^updateProfile$', views.UpdateProfile, name='UpdateProfile'),
    url(r'home/edit_profile', views.EditProfile, name='EditProfile'),
    url(r'home/add_project', views.AddProject, name='AddProject'),
    url(r'home/about', views.about, name='about'),
    url(r'home/pre_index', views.pre_index, name='pre_index'),
]
