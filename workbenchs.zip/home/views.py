from django.contrib.auth import authenticate, login
from django.contrib.auth import logout
from django.http import JsonResponse
from django.shortcuts import render, get_object_or_404
from django.db.models import Q
from .forms import UserForm,QueForm,AnsForm
from .models import *
from django.http import HttpResponse


IMAGE_FILE_TYPES = ['png', 'jpg', 'jpeg']

# Create your views here.
def logout_user(request):
    logout(request)
    form = UserForm(request.POST or None)
    context = {
        "form": form,
    }
    return render(request, 'home/pre_index.html', context)


def login_user(request):
    if request.method == "POST":
        username = request.POST['username']
        password = request.POST['password']
        user = authenticate(username=username, password=password)
        if user is not None:
            if user.is_active:
                login(request, user)
                ques = Que.objects.filter(user=request.user)
                return render(request, 'home/index.html', {'ques': ques})
            else:
                return render(request, 'home/login.html', {'error_message': 'Your account has been disabled'})
        else:
            return render(request, 'home/login.html', {'error_message': 'Invalid login'})
    return render(request, 'home/login.html')


def register(request):
    form = UserForm(request.POST or None)
    if form.is_valid():
        user = form.save(commit=False)
        username = form.cleaned_data['username']
        password = form.cleaned_data['password']
        user.set_password(password)
        user.save()
        user = authenticate(username=username, password=password)
        if user is not None:
            if user.is_active:
                login(request, user)
                ques = Que.objects.filter(user=request.user)
                return render(request, 'home/index.html', {'ques': ques})
    context = {
        "form": form,
    }
    return render(request, 'home/register.html', context)

def index(request):
    if not request.user.is_authenticated():
        ques = Que.objects.all()
        ans_results = Ans.objects.all()
        query = request.GET.get("q")
        if query:
            ques = ques.filter(
                Q(question__icontains=query)
            ).distinct()
            ans_results = ans_results.filter(
                Q(answer__icontains=query)
            ).distinct()
            return render(request, 'home/pre_index.html', {
                'ques': ques,
                'ans': ans_results,
            })
        else:
            return render(request, 'home/pre_index.html', {'ques': ques})
    else:
        ques = Que.objects.all()
        ans_results = Ans.objects.all()
        query = request.GET.get("q")
        if query:
            ques = ques.filter(
                Q(question__icontains=query)
            ).distinct()
            ans_results = ans_results.filter(
                Q(answer__icontains=query)
            ).distinct()
            return render(request, 'home/index.html', {
                'ques': ques,
                'ans': ans_results,
            })
        else:
            return render(request, 'home/index.html', {'ques': ques})
def create_que(request):
    if not request.user.is_authenticated():
        return render(request, 'home/pre_index.html')
    else:
        form = QueForm(request.POST or None, request.FILES or None)
        if form.is_valid():
            que = form.save(commit=False)
            que.user = request.user
            que.save()
            return render(request, 'home/detail.html', {'que': que})
        context = {
            "form": form,
        }
        return render(request, 'home/create_que.html', context)


def create_ans(request, que_id):
    form = AnsForm(request.POST or None, request.FILES or None)
    que = get_object_or_404(Que, pk=que_id)
    if form.is_valid():
        ques_anss = que.ans_set.all()
        for s in ques_anss:
            if s.answer == form.cleaned_data.get("answer"):
                context = {
                    'que': que,
                    'form': form,
                    'error_message': 'You already added that ans',
                }
                return render(request, 'home/create_ans.html', context)
        ans = form.save(commit=False)
        ans.que = que
        ans.user = request.user
        ans.save()
        return render(request, 'home/detail.html', {'que': que})
    context = {
        'que': que,
        'form': form,
    }
    return render(request, 'home/create_ans.html', context)

def detail(request, que_id):
    if not request.user.is_authenticated():
        user = request.user
        que = get_object_or_404(Que, pk=que_id)
        return render(request, 'home/pre_detail.html', {'que': que, 'user': user})
    else:
        user = request.user
        que = get_object_or_404(Que, pk=que_id)
        return render(request, 'home/detail.html', {'que': que, 'user': user})

def delete_que(request, que_id):
    que = Que.objects.get(pk=que_id)
    que.delete()
    ques = Que.objects.filter(user=request.user)
    return render(request, 'home/index.html', {'ques': ques})

def favorite(request, ans_id):
    ans = get_object_or_404(Ans, pk=ans_id)
    try:
        if ans.is_favorite:
            ans.is_favorite = False
        else:
            ans.is_favorite = True
        ans.save()
    except (KeyError, Ans.DoesNotExist):
        return JsonResponse({'success': False})
    else:
        return JsonResponse({'success': True})


def favorite_que(request, que_id):
    que = get_object_or_404(Que, pk=que_id)
    try:
        if que.is_favorite:
            que.is_favorite = False
        else:
            que.is_favorite = True
        que.save()
    except (KeyError, Que.DoesNotExist):
        return JsonResponse({'success': False})
    else:
        return JsonResponse({'success': True})

def delete_ans(request, que_id, ans_id):
    que = get_object_or_404(Que, pk=que_id)
    ans = Ans.objects.get(pk=ans_id)
    ans.delete()
    return render(request, 'home/detail.html', {'que': que})


def anss(request, filter_by):
    if not request.user.is_authenticated():
        return render(request, 'home/login.html')
    else:
        try:
            ans_ids = []
            for que in Que.objects.filter(user=request.user):
                for ans in que.ans_set.all():
                    ans_ids.append(ans.pk)
            users_anss = Ans.objects.filter(pk__in=ans_ids)
            if filter_by == 'favorites':
                users_anss = users_anss.filter(is_favorite=True)
        except Que.DoesNotExist:
            users_anss = []
        return render(request, 'home/anss.html', {
            'ans_list': users_anss,
            'filter_by': filter_by,
        })







def Home(request):
    return HttpResponse("<h1>Welcome to BMU Workbench</h1>")

# def UpdateProfile(request):
def UpdateProfile(request):
    # if this is a POST request we need to process the form data
    # create a form instance and populate it with data from the request:
    form = ProfileForm(request.POST)
    if request.method == 'POST':
        # fields = ('user', 'name', 'kind', 'bio', 'skills', 'email', 'phoneNumber', 'profile_image')
        pro = form.save(commit=False)
        pro.user = request.user
        pro.save()
        profile = Profile.objects.filter(request.user)
        # check if it is valid
        if form.is_valid():
            return render(request, 'home/profile.html',{'profile' : profile})
    else:
        # form = ProfileForm()
        # profile = Profile.objects.filter(request.user)
        return HttpResponse("<h1>Not Saved</h1>")
        # return render(request, 'profile.html',{'form' : form})


def CreateProfile(request):
    if not request.user.is_authenticated():
        return render(request, 'home/login.html')
    else:
        profile = Profile.objects.filter(user=request.user)
        project = Project.objects.filter(user=request.user)
        return render(request, 'home/profile.html', {'profile': profile, 'project' : project})






def EditProfile(request):
    if not request.user.is_authenticated():
        return render(request, 'home/profile.html')
    else:
        form = ProfileForm(request.POST)
        if form.is_valid():
            profile = form.save(commit=False)
            profile.user = request.user
            profile.profile_image = request.FILES['profile_image']
            profile.save()
            return render(request, 'home/index.html', {'profile': profile})
        context = {
            "form": form,
        }
        return render(request, 'home/edit_profile.html', context)


def AddProject(request):
    if not request.user.is_authenticated():
        return render(request, 'home/login.html')
    else:
        form = ProjectForm(request.POST or None, request.FILES or None)
        if form.is_valid():
            project = form.save(commit=False)
            project.user = request.user
            project.save()
            return render(request, 'home/index.html')
        context = {
            "form": form,
        }
        return render(request, 'home/add_project.html', context)

def about(request):
    return render(request, 'home/about.html')

def pre_index(request):
    return render(request, 'home/pre_index.html')