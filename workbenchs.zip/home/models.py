from django.contrib.auth.models import Permission, User
from django.db import models
from django.forms import ModelForm



class Que(models.Model):
    user = models.ForeignKey(User, default=1)
    question = models.CharField(max_length=500)
    description = models.CharField(max_length=100)
    is_favorite = models.BooleanField(default=False)

    def __str__(self):
        return self.question


class Ans(models.Model):
    user = models.ForeignKey(User, default=1)
    que = models.ForeignKey(Que, on_delete=models.CASCADE)
    answer = models.CharField(max_length=500)
    is_favorite = models.BooleanField(default=False)

    def __str__(self):
        return self.answer





class Profile(models.Model):
    user = models.ForeignKey('auth.User')
    name = models.CharField(max_length=100, blank=True)
    kind = models.CharField(max_length=10, blank=True)
    bio = models.TextField(blank=True)
    skills = models.CharField(max_length=250, blank=True)  # type student or teacher
    profile_image = models.ImageField(upload_to='static/', default='static/rossi.png')
    email = models.CharField(max_length=250)
    phoneNumber = models.CharField(max_length=250)
    def publish(self):
        self.save()

    def __str__(self):
        return self.name
class ProfileForm(ModelForm):
    class Meta:
        model = Profile
        fields = ('name','kind', 'bio', 'skills', 'email', 'phoneNumber', 'profile_image')
        # fields = ('user', 'name','kind', 'bio', 'skills', 'email', 'phoneNumber', 'profile_image')

# now creating model for project work
class Project(models.Model):
    user = models.ForeignKey('auth.User')
    title = models.CharField(max_length=100, blank=True)
    text = models.TextField(blank=True)
    startDate = models.DateField(blank=True, null=True)
    endDate = models.DateField(blank=True, null=True)


    def publish(self):
        self.save()


    def __str__(self):
        return self.title


class ProjectForm(ModelForm):
    class Meta:
        model = Project
        fields = ('title', 'text', 'startDate', 'endDate')